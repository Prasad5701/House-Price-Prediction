# Housing-Price-Prediction


The goal is to build a regression model to forecast the price of houses. 
The dataset is pre-processed by analysing the missing values. 
The various Regression algorithms are used to predict the price of housing.
